import { createAdapter, createCustomAdapter } from "./adapters/providers.js";
import { composerText } from "./adapters/dom.js";
import { AgentCore } from "./core/agent-core.js";
import { clockAlive, startClock } from "./core/clock.js";
import { BridgeClient } from "./core/bridge-client.js";
import { loadSettings, prefsFor, saveProviderPrefs, saveSettings } from "./core/settings.js";
import { AgentPanel } from "./ui/panel.js";
import type { RuntimeResponse, TabAgentState } from "../../shared/src/protocol.js";
import type { CommunityData } from "../../shared/src/library/community.js";
import type { PackLite } from "../../shared/src/library/tasks.js";

/** Content script entry: pick the provider adapter, mount the panel, keep it mounted across SPA re-renders. */
(async function main() {
  if ((window as unknown as { __brickwire?: boolean }).__brickwire) return;
  (window as unknown as { __brickwire?: boolean }).__brickwire = true;
  const settings = await loadSettings();
  const host = location.hostname.toLowerCase();
  const custom = settings.customSites.find((c) => host === c.host || host.endsWith("." + c.host));
  const adapter = createAdapter(host) ?? (custom ? createCustomAdapter(custom) : null);
  if (!adapter) return;
  if (adapter.info.id !== "custom" && settings.providers[adapter.info.id] === false) return; // disabled in Options

  startClock(); // background-tab-proof timers (the chat tab is hidden while the user works in Studio)
  const bridge = new BridgeClient();
  let core: AgentCore;
  const report = () => {
    const state: TabAgentState = {
      provider: adapter.info.id,
      providerName: adapter.info.name,
      active: core.active,
      stage: core.stage,
      task: core.task,
      sessionId: core.sessionId,
      url: location.href,
    };
    try {
      chrome.runtime.sendMessage({ type: "tabState", state }, () => void chrome.runtime.lastError);
    } catch {
      /* extension reloaded */
    }
  };
  const panel = new AgentPanel(
    adapter.info.name,
    {
      start: () => void core.start(),
      stop: () => void core.stop(),
      pause: () => core.pause(),
      approve: (id, ok) => void core.approve(id, ok),
      approveAll: (id) => void core.approveAll(id),
      setCategory: (c) => {
        void saveProviderPrefs(adapter.info.id, { category: c });
        void core.setCategory(c);
      },
      setMode: (m) => {
        void saveProviderPrefs(adapter.info.id, { mode: m });
        void core.setMode(m);
      },
      switchProvider: (url) => chrome.runtime.sendMessage({ type: "openUrl", url }),
      openBridge: () => chrome.runtime.sendMessage({ type: "openDashboard" }),
      openSettings: () => chrome.runtime.sendMessage({ type: "openOptions" }),
      toggleCollapsed: (c) => void saveSettings({ panelCollapsed: c }),
      toggleFloating: (f) => {
        void saveSettings({ panelFloating: f });
        userFloating = f;
        ensureMounted();
      },
      setSuperMode: (on) => {
        void saveProviderPrefs(adapter.info.id, { superMode: on });
        void core.setSuperMode(on);
      },
      setNotionLog: (on) => {
        void saveProviderPrefs(adapter.info.id, { notionLog: on });
        void core.setNotionLog(on);
      },
      useResource: (text) => void core.submitTask(text),
      fillComposer: (text) => core.fillComposer(text),
      loadPreviews: async () => {
        const r = await fetch(chrome.runtime.getURL("library/previews.json"));
        return (await r.json()) as Record<string, string>;
      },
      loadPacks: async () => {
        const r = await fetch(chrome.runtime.getURL("library/packs.json"));
        return (await r.json()) as PackLite[];
      },
      resourceUrl: (p) => chrome.runtime.getURL(p),
      loadCommunity: async () => {
        try {
          const c = await chrome.storage.local.get("communityCache");
          if (c?.communityCache?.items?.length) return c.communityCache as CommunityData;
        } catch {
          /* fall back to the bundled file */
        }
        const r = await fetch(chrome.runtime.getURL("library/community.json"));
        return (await r.json()) as CommunityData;
      },
      refreshCommunity: async () => {
        const r: RuntimeResponse<CommunityData> = await chrome.runtime.sendMessage({ type: "communityRefresh" });
        if (!r?.ok || !r.data?.items?.length) throw new Error(r?.error ?? "no data");
        try {
          await chrome.storage.local.set({ communityCache: r.data });
        } catch {
          /* quota — keep it in memory only */
        }
        return r.data;
      },
      thumb: async (url) => {
        const r: RuntimeResponse<string> = await chrome.runtime.sendMessage({ type: "thumb", url, size: 192 });
        if (!r?.ok || typeof r.data !== "string") throw new Error(r?.error ?? "no thumbnail");
        return r.data;
      },
      siteCheck: () => {
        const r = adapter.diagnose();
        const lines = [`Site check — ${adapter.info.name} (${location.hostname}${location.pathname.slice(0, 40)})`, ...r.lines];
        lines.push(`${clockAlive() ? "✓" : "✕"} background timer: ${clockAlive() ? "alive (works in hidden tabs)" : "not connected — reload the tab"}`);
        lines.push(`· tab ${document.hidden ? "hidden" : "visible"} · agent ${core.active ? "active" : "idle"} · stage ${core.stage}`);
        lines.push(r.ok ? "Result: OK" : "Result: problems found — send this text + a screenshot to the developer");
        try {
          void navigator.clipboard?.writeText(lines.join("\n")).catch(() => undefined);
        } catch {
          /* no clipboard */
        }
        return lines;
      },
    },
    settings.panelCollapsed,
    adapter.info.id,
    prefsFor(settings, adapter.info.id),
  );
  core = new AgentCore(adapter, bridge, panel, settings, report);
  if (adapter.info.status === "experimental") panel.notify(`${adapter.info.name} support is experimental: ${adapter.info.notes}`, "warn");

  // mount + self-heal (SPAs replace the composer on navigation)
  let mountedOnce = false;
  const startOnce = () => {
    if (mountedOnce) return;
    mountedOnce = true;
    core.startMonitoring();
    // page reload mid-session: restore the running agent for this chat
    void core.tryResume().then((ok) => ok && report());
  };
  const bootAt = Date.now();
  let userFloating = settings.panelFloating;
  let autoFloated = false;
  const ensureMounted = () => {
    if (panel.floating && autoFloated && !userFloating && adapter.getComposer()) {
      autoFloated = false; // message box showed up: dock again
      panel.setFloating(false);
    }
    if (panel.floating) {
      if (panel.host.parentElement !== document.body) document.body.appendChild(panel.host);
      if (adapter.getComposer()) startOnce();
      return;
    }
    if (!mountedOnce && !autoFloated && Date.now() - bootAt > 10000 && !adapter.getComposer()) {
      // the message box was not recognised: show the panel floating so Site check is reachable
      autoFloated = true;
      panel.setFloating(true);
      panel.notify(`${adapter.info.name}: message box not found yet. Open a chat, then press Site check if this stays.`, "warn");
      return ensureMounted();
    }
    if (panel.host.isConnected && adapter.getComposer()) {
      // still placed before the current composer?
      const c = adapter.getComposer()!;
      if (panel.host.compareDocumentPosition(c) & Node.DOCUMENT_POSITION_FOLLOWING) return;
    }
    if (adapter.injectAgentUI(panel.host)) startOnce();
  };
  if (settings.panelFloating) panel.setFloating(true);
  ensureMounted();
  let pending = false;
  new MutationObserver(() => {
    if (pending) return;
    pending = true;
    requestAnimationFrame(() => {
      pending = false;
      ensureMounted();
    });
  }).observe(document.documentElement, { childList: true, subtree: true });
  setInterval(ensureMounted, 2000);

  chrome.runtime.onMessage.addListener((msg: { type: string }, _s: unknown, reply: (r: unknown) => void) => {
    if (msg?.type === "agent:stop") void core.stop().then(() => reply({ ok: true }));
    else if (msg?.type === "agent:state") {
      report();
      reply({ ok: true, active: core.active, stage: core.stage, provider: adapter.info.name });
    } else return false;
    return true;
  });
  // Messages the USER sends themselves carry no delivery marker: note them as reply boundaries.
  const userSubmit = (e: Event) => {
    if (!e.isTrusted) return; // our own sends dispatch synthetic events
    const c = adapter.getComposer();
    if (!c) return;
    const t = e.target as Node | null;
    if (e.type === "keydown") {
      const k = e as KeyboardEvent;
      if (k.key !== "Enter" || k.shiftKey || k.isComposing || !t || !c.contains(t)) return;
    } else {
      const btn = (t as HTMLElement | null)?.closest?.("button,[role='button']");
      if (!btn || btn.closest("[data-brickwire-host]")) return;
      let scope: HTMLElement | null = c;
      for (let i = 0; i < 5 && scope?.parentElement; i++) scope = scope.parentElement;
      if (!scope?.contains(btn)) return;
    }
    const text = composerText(c);
    if (text.trim()) adapter.noteUserMessage(text);
  };
  document.addEventListener("keydown", userSubmit, true);
  document.addEventListener("click", userSubmit, true);
  report();
})();
