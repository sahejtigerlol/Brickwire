#!/usr/bin/env node
/**
 * One-command launcher: starts the bridge (unless already running), then prints an honest,
 * live status of the whole chain until Studio is really usable:
 *   [BRIDGE] up?   [MCP] StudioMCP process + how many tools it advertises   [STUDIO] place open?
 * Green "READY" is printed only when the bridge reports MCP_READY (tools > 0 and a place is open).
 * Ctrl+C stops the bridge it started.
 */
import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
let port = process.env.BRICKWIRE_PORT;
try {
  const env = fs.readFileSync(path.join(ROOT, ".env"), "utf8");
  port ??= env.match(/^BRICKWIRE_PORT=(\d+)/m)?.[1];
} catch {}
port ??= "47821";
const URL_ = `http://127.0.0.1:${port}`;
const color = process.stdout.isTTY && !process.env.NO_COLOR;
const c = (code, s) => (color ? `\x1b[${code}m${s}\x1b[0m` : s);
const G = (s) => c(32, s), Y = (s) => c(33, s), R = (s) => c(31, s), D = (s) => c(90, s);
const ts = () => new Date().toTimeString().slice(0, 8);
const say = (s) => console.log(`${D(ts())} ${s}`);

async function health() {
  try {
    const r = await fetch(`${URL_}/api/health`, { signal: AbortSignal.timeout(2000) });
    return await r.json();
  } catch {
    return null;
  }
}

let child = null;
const logDir = path.join(ROOT, "logs");
async function main() {
  console.log(`Brickwire launcher — bridge ${URL_}`);
  if (await health()) {
    say(G("[BRIDGE] already running") + " — monitoring only (use stop.command on macOS or stop.bat on Windows to stop it)");
  } else {
    const entry = path.join(ROOT, "bridge", "dist", "bridge.mjs");
    if (!fs.existsSync(entry)) {
      say(R("[BRIDGE] bridge/dist/bridge.mjs missing — run install.command (macOS) or install.bat (Windows)"));
      process.exit(1);
    }
    fs.mkdirSync(logDir, { recursive: true });
    const logFile = path.join(logDir, "bridge.log");
    const out = fs.openSync(logFile, "a");
    child = spawn(process.execPath, [entry], { cwd: ROOT, stdio: ["ignore", out, out], env: process.env });
    child.on("exit", (code) => {
      say(R(`[BRIDGE] exited (code ${code}). See ${logFile}`));
      process.exit(code ?? 1);
    });
    say(`[BRIDGE] starting… (log: ${logFile})`);
  }

  let last = "";
  let readyShown = false;
  let zeroToolsSince = null;
  for (;;) {
    const h = await health();
    let line, base;
    if (!h) line = Y("[BRIDGE] not responding yet…");
    else {
      const m = h.mcp ?? {};
      const bridge = G("[BRIDGE] OK");
      const mcp =
        m.state === "ready"
          ? m.toolCount > 0
            ? G(`[MCP] ${m.serverName ?? "StudioMCP"} — ${m.toolCount} tools`)
            : Y("[MCP] running, 0 tools (Studio not attached yet)")
          : m.state === "disabled"
            ? R(`[MCP] not found — ${h.reason}`)
            : m.state === "error"
              ? R(`[MCP] error — ${m.lastError ?? h.reason}`)
              : Y(`[MCP] ${m.state}…`);
      const studio =
        h.state === "MCP_READY" || h.state === "SESSION_ACTIVE"
          ? G(`[STUDIO] ${h.studio?.selected?.name ?? "place"} open`)
          : h.studio?.placeOpen === false
            ? Y("[STUDIO] connected, but no place is open — open a place")
            : Y(`[STUDIO] ${h.reason}`);
      line = `${bridge}  ${mcp}  ${studio}`;
      base = line;
      if (m.state === "ready" && !(m.toolCount > 0)) {
        zeroToolsSince ??= Date.now();
        if (Date.now() - zeroToolsSince > 30000 && !readyShown) {
          line += "\n         " + Y("Hint: open Roblox Studio, open a place, and enable the MCP server (Assistant → ⋯ → Manage MCP Servers / Studio as MCP server).");
          zeroToolsSince = Date.now() + 60000;
        }
      } else zeroToolsSince = null;
      const ok = h.state === "MCP_READY" || h.state === "SESSION_ACTIVE";
      if (ok && !readyShown) {
        readyShown = true;
        line += "\n\n  " + G("READY") + " — open https://chat.deepseek.com, click \"Start Agent\" in the Brickwire panel.\n  Dashboard: " + URL_ + "/\n  Keep this window open. Ctrl+C stops the bridge.\n";
      }
      if (!ok) readyShown = false;
    }
    base ??= line;
    if (base !== last) {
      say(line);
      last = base;
    }
    await new Promise((r) => setTimeout(r, 1500));
  }
}

for (const sig of ["SIGINT", "SIGTERM"]) process.on(sig, () => { child?.kill(); process.exit(0); });
main();
