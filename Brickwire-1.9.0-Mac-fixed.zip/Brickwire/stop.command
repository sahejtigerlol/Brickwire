#!/bin/sh
set -u
cd "$(dirname "$0")" || exit 1

PORT="${BRICKWIRE_PORT:-47821}"
if [ -f .env ]; then
  value="$(sed -n 's/^BRICKWIRE_PORT[[:space:]]*=[[:space:]]*//p' .env | head -n 1)"
  [ -n "$value" ] && PORT="$value"
fi

if command -v curl >/dev/null 2>&1; then
  if curl -fsS --max-time 3 -X POST "http://127.0.0.1:${PORT}/api/shutdown" >/dev/null 2>&1; then
    echo "[OK] Bridge stopped."
    exit 0
  fi
fi

echo "[i] Bridge was not running on port ${PORT}."
