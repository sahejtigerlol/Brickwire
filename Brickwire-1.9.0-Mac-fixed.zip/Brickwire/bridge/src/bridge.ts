import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import crypto from "node:crypto";
import { EventEmitter } from "node:events";
import {
  BRIDGE_VERSION,
  PROTOCOL_VERSION,
  type BridgeSettings,
  type BridgeState,
  type CallEnvelope,
  type HealthResponse,
  type SessionStartResponse,
  type StudioInfo,
  type ToolCall,
  type ToolDescriptor,
  type ToolResult,
  type AgentStage,
  type JsonSchema,
} from "../../shared/src/protocol.js";
import { validateArgs, closestNames, coerceArgs, resolveToolName } from "../../shared/src/validation.js";
import { assessCall, decide, riskFromName, findLuauCode } from "../../shared/src/safety.js";
import { validateCallShape } from "../../shared/src/parser.js";
import type { BridgeConfig } from "./config.js";
import { Logger, clip } from "./logger.js";
import { usesHelpers, prepareLuau, remapLuauLines } from "../../shared/src/bw-luau.js";
import { AssetLibrary } from "./assets.js";
import { guideFor, GUIDE_TOPICS } from "../../shared/src/guides.js";
import { studioMcpCandidatesWindows } from "./config.js";
import { McpStdioClient, McpError, normalizeMcpResult, looksLikeStudioDrop, STALE_PROXY_HINT } from "./mcp-client.js";
import { COMPOSITE_TOOLS, type CompositeContext, type CompositeTool, type SnapshotRecord } from "./composites.js";
import { extractLuauPayload } from "./luau.js";
import { MemoryStore, projectKeyFor, MEMORY_CATEGORIES, type MemoryCategory, type ProjectMemory } from "./memory.js";
import { SessionManager, type SessionPatch } from "./sessions.js";
import { ApprovalManager } from "./approvals.js";
import { studioProcessRunning, parseStudioList, refreshStudioPaths, runningStudioPaths } from "./studio-detect.js";
import { defaultMcpLauncher } from "./config.js";

const LONG_TOOLS = /^(start_stop_play|generate_|wait_job_finished|subagent|insert_asset|upload_image|screen_capture|character_navigation|user_)/;

interface BridgeTool extends ToolDescriptor {
  composite?: CompositeTool;
  bridgeRun?: (args: Record<string, unknown>, sessionId?: string) => Promise<unknown>;
  /** Alias: the real MCP tool name (e.g. open-source studio MCP "run_code") behind our canonical "execute_luau". */
  mcpName?: string;
  /** Alias: the real argument that carries the Luau source (e.g. "command"). */
  codeKey?: string;
}

/** Luau runners of other Studio MCP servers (open-source studio-rust-mcp-server: run_code {command}, community servers…). */
const LUAU_RUNNER_NAMES = ["run_code", "run_luau", "execute_code", "execute_lua", "run_lua", "run_script", "execute_script", "luau", "eval_luau", "run_command"];

export function findLuauRunner(tools: Array<{ name: string; description?: string; inputSchema?: JsonSchema }>): { name: string; codeKey: string } | null {
  const pick = (t: (typeof tools)[number]) => {
    const props = t.inputSchema?.properties ?? {};
    const key =
      ["code", "command", "source", "luau", "script", "lua", "src"].find((k) => k in props) ??
      Object.keys(props).find((k) => props[k]?.type === "string" && !/studio|datamodel|id$/i.test(k));
    return key ? { name: t.name, codeKey: key } : null;
  };
  for (const n of LUAU_RUNNER_NAMES) {
    const t = tools.find((x) => x.name.toLowerCase() === n);
    if (t) {
      const r = pick(t);
      if (r) return r;
    }
  }
  const t = tools.find((x) => /\b(luau|lua)\b/i.test(x.description ?? "") && /\b(run|execute|eval)/i.test(x.name + " " + (x.description ?? "")) && !/script_source|edit|grep|search/i.test(x.name));
  return t ? pick(t) : null;
}

export class Bridge extends EventEmitter {
  readonly logger: Logger;
  readonly mcp: McpStdioClient;
  readonly memory: MemoryStore;
  readonly sessions: SessionManager;
  readonly approvals = new ApprovalManager();
  readonly assets: AssetLibrary;
  settings: BridgeSettings;
  studios: StudioInfo[] = [];
  studioProcess: boolean | null = null;
  /** From get_studio_state: true = place open, false = Studio on the start screen, null = unknown. */
  placeOpen: boolean | null = null;
  private tools = new Map<string, BridgeTool>();
  private calls = new Map<string, CallEnvelope & { waiters: Array<() => void>; createdAt: number }>();
  private pollTimer: NodeJS.Timeout | null = null;
  private settingsFile: string;
  private hasListStudios = false;
  private luauPrint: boolean;
  private luauAliasLogged = "";

  constructor(readonly config: BridgeConfig, opts: { quiet?: boolean } = {}) {
    super();
    fs.mkdirSync(config.dataDir, { recursive: true });
    this.logger = new Logger(path.join(config.dataDir, "logs"), config.logLevel, !!opts.quiet);
    this.memory = new MemoryStore(path.join(config.dataDir, "projects"));
    this.sessions = new SessionManager(config.dataDir);
    this.settingsFile = path.join(config.dataDir, "settings.json");
    try {
      fs.mkdirSync(path.join(config.dataDir, "packs"), { recursive: true });
    } catch {
      /* read-only data dir */
    }
    this.assets = new AssetLibrary(
      { bundled: [...new Set([path.join(config.baseDir, "packs", "built"), path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..", "packs", "built")])], user: [path.join(config.dataDir, "packs"), path.join(config.baseDir, "packs", "user")] },
      this.logger,
    );
    this.luauPrint = config.luauPrintResults;
    this.settings = {
      mode: config.mode,
      toolTimeoutMs: 60000,
      approvalTimeoutMs: 300000,
      autoSnapshot: true,
      maxResultChars: 24000,
      selectedStudioId: null,
    };
    try {
      Object.assign(this.settings, JSON.parse(fs.readFileSync(this.settingsFile, "utf8")));
    } catch {
      /* defaults */
    }
    this.mcp = new McpStdioClient({
      command: config.mcpCommand,
      args: config.mcpArgs,
      cwd: config.baseDir,
      logger: this.logger,
      clientVersion: BRIDGE_VERSION,
    });
    this.mcp.healer = () => this.healStaleProxy();
    this.mcp.on("tools", () => {
      this.rebuildRegistry();
      void this.pollStudios();
      this.emit("changed");
    });
    this.mcp.on("state", (s) => {
      this.logger.info("mcp.state", s);
      if (s === "ready") void this.pollStudios();
      else {
        this.studios = [];
        this.placeOpen = null;
      }
      this.rebuildRegistry();
      this.emit("changed");
    });
    this.approvals.on("changed", () => this.emit("changed"));
    this.rebuildRegistry();
  }

  async start() {
    this.logger.info("bridge.start", `Brickwire bridge ${BRIDGE_VERSION}; MCP: ${this.mcp.commandLine ?? "not configured"} (${this.config.mcpReason})`);
    void this.mcp.start();
    this.pollTimer = setInterval(() => void this.pollStudios(), this.config.studioPollMs);
  }

  async stop() {
    if (this.pollTimer) clearInterval(this.pollTimer);
    this.approvals.rejectAll();
    if (this.sessions.current) this.endSession(this.sessions.current.id);
    await this.mcp.stop();
  }

  saveSettings(patch: Partial<BridgeSettings>) {
    const s = this.settings;
    if (patch.mode && ["full", "auto", "approval", "safe"].includes(patch.mode)) s.mode = patch.mode;
    if (typeof patch.toolTimeoutMs === "number") s.toolTimeoutMs = Math.min(600000, Math.max(5000, patch.toolTimeoutMs));
    if (typeof patch.approvalTimeoutMs === "number") s.approvalTimeoutMs = Math.min(3600000, Math.max(10000, patch.approvalTimeoutMs));
    if (typeof patch.autoSnapshot === "boolean") s.autoSnapshot = patch.autoSnapshot;
    if (typeof patch.maxResultChars === "number") s.maxResultChars = Math.min(200000, Math.max(2000, patch.maxResultChars));
    if (patch.selectedStudioId !== undefined) s.selectedStudioId = patch.selectedStudioId;
    fs.writeFileSync(this.settingsFile, JSON.stringify(s, null, 2));
    this.logger.info("settings.updated", JSON.stringify(s));
    this.emit("changed");
    return s;
  }

  // ------------------------------------------------------------------ registry
  private rebuildRegistry() {
    const map = new Map<string, BridgeTool>();
    const mcpNames = new Set(this.mcp.tools.map((t) => t.name));
    this.hasListStudios = mcpNames.has("list_roblox_studios");
    for (const t of this.mcp.tools) {
      const blocked = this.config.blockedTools.includes(t.name);
      const ann = t.annotations ?? {};
      let risk = riskFromName(t.name);
      if (ann.destructiveHint === true) risk = "destructive";
      else if (ann.readOnlyHint === true && t.name !== "execute_luau") risk = "read";
      map.set(t.name, {
        name: t.name,
        description: t.description ?? "",
        inputSchema: t.inputSchema ?? { type: "object" },
        source: "mcp",
        risk,
        available: !blocked,
        unavailableReason: blocked ? "blocked by bridge policy (BRICKWIRE_BLOCKED_TOOLS)" : undefined,
      });
    }
    if (!map.has("execute_luau")) {
      // Another Studio MCP server (e.g. open-source "run_code"): expose it under the canonical name so prompts,
      // BW helpers, snapshots and composites work unchanged.
      const runner = findLuauRunner(this.mcp.tools);
      const real = runner && map.get(runner.name);
      if (runner && real && real.available) {
        const { [runner.codeKey]: _src, ...rest } = real.inputSchema.properties ?? {};
        map.set("execute_luau", {
          ...real,
          name: "execute_luau",
          description: `Run Luau code in Roblox Studio (served by MCP tool "${runner.name}"). ${real.description}`.trim(),
          inputSchema: {
            ...real.inputSchema,
            properties: { code: { type: "string", description: "Luau source to run" }, ...rest },
            required: ["code", ...(real.inputSchema.required ?? []).filter((r) => r !== runner.codeKey)],
          },
          risk: riskFromName("execute_luau"),
          mcpName: runner.name,
          codeKey: runner.codeKey,
        });
        mcpNames.add("execute_luau");
        if (this.luauAliasLogged !== runner.name) {
          this.luauAliasLogged = runner.name;
          this.logger.info("tool.luau_alias", `execute_luau → ${runner.name}(${runner.codeKey})`);
        }
      }
    }
    for (const c of this.config.composites ? COMPOSITE_TOOLS : []) {
      if (map.has(c.name)) continue; // real MCP tool with same name wins
      const missing = c.requires.filter((r) => !mcpNames.has(r));
      map.set(c.name, {
        name: c.name,
        description: c.description,
        inputSchema: c.inputSchema,
        source: "composite",
        risk: c.risk,
        available: missing.length === 0,
        unavailableReason: missing.length ? `requires MCP tool(s) ${missing.join(", ")} which Studio does not currently provide` : undefined,
        requires: c.requires,
        composite: c,
      });
    }
    const bridgeTools: BridgeTool[] = [
      {
        name: "memory_get",
        description: "Read persistent project memory (systems, important scripts/GUIs, previous changes, known errors).",
        inputSchema: { type: "object", properties: {} },
        source: "bridge",
        risk: "read",
        available: true,
        bridgeRun: async (_a, sid) => {
          const m = this.projectFor(sid);
          return m ? { summary: this.memory.summary(m), snapshots: m.snapshots.slice(-10).map((s) => ({ id: s.id, label: s.label, createdAt: s.createdAt })) } : { summary: "" };
        },
      },
      {
        name: "memory_note",
        description: `Save a fact to project memory so future sessions don't break it. category: ${MEMORY_CATEGORIES.join("|")}.`,
        inputSchema: {
          type: "object",
          required: ["category", "text"],
          properties: { category: { type: "string", enum: [...MEMORY_CATEGORIES] }, text: { type: "string" }, path: { type: "string" } },
        },
        source: "bridge",
        risk: "read",
        available: true,
        bridgeRun: async (a, sid) => {
          const m = this.projectFor(sid);
          if (!m) throw new Error("no active project (start a session first)");
          this.memory.addItem(m, a.category as MemoryCategory, String(a.text), a.path ? String(a.path) : undefined);
          return { saved: true };
        },
      },
      {
        name: "list_snapshots",
        description: "List snapshots (ids, labels, paths) available for restore_snapshot.",
        inputSchema: { type: "object", properties: {} },
        source: "bridge",
        risk: "read",
        available: true,
        bridgeRun: async (_a, sid) =>
          (this.projectFor(sid)?.snapshots ?? []).slice(-20).map((s) => ({ id: s.id, label: s.label, createdAt: s.createdAt, paths: s.entries.map((e) => e.path), restoredAt: s.restoredAt ?? null })),
      },
      {
        name: "brickwire_assets",
        description:
          "Search the asset packs (ndc props, retro classic Roblox, ultimate building materials, textures, vfx meshes + user packs): real meshes, textures, decals, skies, sounds, VFX with meaningful names. Returns ids for BW.asset(id, {At=…}). No query → pack overview. id → details + instance outline.",
        inputSchema: {
          type: "object",
          properties: {
            query: { type: "string", description: "words, e.g. 'wooden barrel', 'brick texture', 'night sky', 'shockwave'" },
            kind: { type: "string", enum: ["mesh", "texture", "decal", "vfx", "sky", "sound", "part", "model", "character", "lighting", "ui", "script", "other"] },
            pack: { type: "string" },
            category: { type: "string" },
            id: { type: "string", description: "exact asset id for details" },
            limit: { type: "number" },
            offset: { type: "number" },
          },
        },
        source: "bridge",
        risk: "read",
        available: true,
        bridgeRun: async (a) => {
          const lib = this.assets.load();
          if (typeof a.id === "string" && a.id) {
            const e = lib.get(a.id);
            if (!e) return { found: false, didYouMean: lib.suggest(a.id) };
            const { bytes: _b, tags: _t, thumbAsset: _th, ...item } = e.item;
            return { found: true, item, outline: lib.outline(e.node).join("\n"), use: `BW.asset("${e.item.id}", {At = {x, y, z}${e.item.kind === "texture" || e.item.kind === "decal" ? ", ApplyTo = part" : ""}})` };
          }
          if (!a.query && !a.kind && !a.category && !a.pack) return { packs: lib.overview(), hint: "search with {query=…}; place with BW.asset(id, {At={x,y,z}})" };
          const r = lib.search({ query: a.query as string, kind: a.kind as string, pack: a.pack as string, category: a.category as string, limit: (a.limit as number) ?? 25, offset: a.offset as number });
          return { total: r.total, items: r.items, use: 'BW.asset("<id>", {At = {x, y, z}, Facing = 0, Scale = 1}) · textures/decals: BW.asset("<id>", {ApplyTo = part})' };
        },
      },
      {
        name: "brickwire_guide",
        description: `In-depth expert guide before hard work: topics ${GUIDE_TOPICS.join(", ")} (understand = clarifying questions & variants, super = deep-quality workflow, camera = cinematography/fly-throughs, cutscene = gacha case/egg/dice reveals, event starts, story intros).`,
        inputSchema: { type: "object", required: ["topic"], properties: { topic: { type: "string", enum: [...GUIDE_TOPICS] } } },
        source: "bridge",
        risk: "read",
        available: true,
        bridgeRun: async (a) => {
          const g = guideFor(String(a.topic));
          if (!g) throw new Error(`unknown topic "${String(a.topic)}" — topics: ${GUIDE_TOPICS.join(", ")}`);
          return g;
        },
      },
    ];
    for (const b of bridgeTools) if (!map.has(b.name)) map.set(b.name, b);
    this.tools = map;
  }

  listTools(): ToolDescriptor[] {
    return [...this.tools.values()].map(({ composite: _c, bridgeRun: _b, ...d }) => d);
  }

  // ------------------------------------------------------------------ studio
  private polling = false;
  async pollStudios() {
    if (this.polling) return;
    this.polling = true;
    try {
      this.studioProcess = await studioProcessRunning();
      await this.rediscoverMcp();
      if (this.mcp.state !== "ready") return;
      await this.mcp.ensureTools(); // StudioMCP shows 0 tools until Studio attaches — keep asking
      const before = JSON.stringify([this.studios, this.placeOpen]);
      if (this.hasListStudios) {
        try {
          const r = normalizeMcpResult(await this.mcp.callTool("list_roblox_studios", {}, 8000));
          const list = parseStudioList(r.text, r.json).filter((s) => s.name !== "null");
          this.studios = list;
          if (this.settings.selectedStudioId && !list.some((s) => s.id === this.settings.selectedStudioId)) this.settings.selectedStudioId = null;
        } catch (e) {
          this.logger.debug("studio.poll_failed", (e as Error).message);
        }
      }
      if (this.mcp.tools.some((t) => t.name === "get_studio_state") && (!this.hasListStudios || this.studios.length)) {
        try {
          const args: Record<string, unknown> = {};
          const t = this.tools.get("get_studio_state");
          if (t) this.autofill(t, args);
          const r = normalizeMcpResult(await this.mcp.callTool("get_studio_state", args, 8000));
          this.placeOpen = !looksLikeStudioDrop(r.text) && !r.isError;
        } catch {
          this.placeOpen = null;
        }
      } else if (this.hasListStudios && !this.studios.length) this.placeOpen = false;
      if (before !== JSON.stringify([this.studios, this.placeOpen])) {
        this.logger.info("studio.instances", (this.studios.map((s) => `${s.name}#${s.id}`).join(", ") || "none") + ` placeOpen=${this.placeOpen}`);
        this.emit("changed");
      }
    } finally {
      this.polling = false;
    }
  }

  private rediscoverAt = 0;
  /**
   * "Program not detected": the bridge may have started before Studio was installed/updated, or picked a stale
   * version folder (Studio auto-updates; Bloxstrap keeps its own copies). While Studio runs but MCP has no tools,
   * re-detect StudioMCP next to the RUNNING Studio executable and switch to it.
   */
  private async rediscoverMcp() {
    if (!this.config.mcpAuto || Date.now() - this.rediscoverAt < 15000) return;
    const m = this.mcp;
    const stuck = m.state === "disabled" || m.state === "error" || (m.state === "ready" && m.tools.length === 0);
    if (!stuck || (this.studioProcess === false && m.state !== "disabled")) return;
    this.rediscoverAt = Date.now();
    const exes = this.studioProcess ? await refreshStudioPaths() : runningStudioPaths;
    const d = defaultMcpLauncher(process.platform, exes);
    if (!d.command) return;
    const now = [d.command, ...d.args].join(" ");
    if (now === m.commandLine && m.state !== "disabled") return;
    this.logger.info("mcp.rediscovered", `${now} (${d.reason})`);
    this.config.mcpCommand = d.command;
    this.config.mcpArgs = d.args;
    this.config.mcpReason = d.reason;
    await m.setCommand(d.command, d.args);
  }

  /**
   * Studio rejected the proxy as out of date ("Client proxy is out of date, restart to update"): Studio was
   * updated, our StudioMCP.exe is from an older build. Try the proxy of the running / newest Studio, then the other
   * installed ones, probing each with get_studio_state; if none is accepted, restart the original one.
   */
  private async healStaleProxy() {
    const exes = await refreshStudioPaths(true).catch(() => runningStudioPaths);
    const before = { command: this.config.mcpCommand, args: this.config.mcpArgs, reason: this.config.mcpReason };
    const cands: Array<{ command: string; args: string[]; reason: string }> = [];
    if (this.config.mcpAuto) {
      if (process.platform === "win32") {
        const dirs = exes.map((e) => path.dirname(e));
        for (const exe of studioMcpCandidatesWindows(process.env, dirs).slice(0, 5))
          cands.push({ command: exe, args: [], reason: `StudioMCP.exe ${dirs.some((d) => d.toLowerCase() === path.dirname(exe).toLowerCase()) ? "next to the running Studio" : "of an installed Studio"} (${path.dirname(exe)})` });
      } else {
        const d = defaultMcpLauncher(process.platform, exes);
        if (d.command) cands.push({ command: d.command, args: d.args, reason: d.reason });
      }
    }
    const current = this.mcp.commandLine;
    const ordered = [...cands.filter((c) => [c.command, ...c.args].join(" ") !== current)];
    for (const c of ordered) {
      this.logger.info("mcp.rediscovered", `${[c.command, ...c.args].join(" ")} (${c.reason}; previous proxy was out of date)`);
      await this.mcp.setCommand(c.command, c.args);
      if (await this.mcp.probeAccepted()) {
        this.config.mcpCommand = c.command;
        this.config.mcpArgs = c.args;
        this.config.mcpReason = c.reason;
        return;
      }
    }
    this.logger.info("mcp.restart", "restarting the Studio MCP proxy (out of date)");
    if (ordered.length && before.command) await this.mcp.setCommand(before.command, before.args);
    else await this.mcp.restart();
  }

  selectedStudio(): StudioInfo | null {
    return this.studios.find((s) => s.id === this.settings.selectedStudioId) ?? this.studios[0] ?? null;
  }

  computeState(): { state: BridgeState; reason: string } {
    const m = this.mcp;
    if (m.state === "disabled") return { state: "BRIDGE_READY", reason: `MCP unavailable: ${this.config.mcpReason}` };
    if (m.state === "connecting") return { state: "MCP_CONNECTING", reason: "Connecting to Roblox Studio MCP…" };
    if (m.state === "error") return { state: "ERROR", reason: `MCP unavailable: ${m.lastError ?? "unknown error"}` };
    if (m.state === "stopped") return { state: "BRIDGE_READY", reason: "MCP stopped" };
    if (m.staleProxy) return { state: "ERROR", reason: STALE_PROXY_HINT };
    if (m.tools.length === 0)
      return {
        state: this.studioProcess === true ? "STUDIO_FOUND" : "STUDIO_NOT_FOUND",
        reason:
          this.studioProcess === true
            ? "Studio is running but not attached to MCP: open a place and enable Assistant → … → Manage MCP Servers → Enable Studio as MCP server."
            : "Studio unavailable: StudioMCP is running but no Roblox Studio is attached (open Studio with a place).",
      };
    if (this.hasListStudios && this.studios.length === 0) {
      if (this.studioProcess === true)
        return { state: "STUDIO_FOUND", reason: "Studio is running but no place is connected: open a place and enable Assistant → … → Manage MCP Servers → Enable Studio as MCP server." };
      return { state: "STUDIO_NOT_FOUND", reason: this.studioProcess === false ? "Studio unavailable: Roblox Studio is not running." : "Studio unavailable: no Studio instance connected to MCP." };
    }
    if (this.placeOpen === false) return { state: "STUDIO_FOUND", reason: "Studio is connected but no place is open — open or create a place." };
    if (this.sessions.current) return { state: "SESSION_ACTIVE", reason: `Session ${this.sessions.current.id} active` };
    return { state: "MCP_READY", reason: "Roblox Studio MCP ready" };
  }

  health(): HealthResponse {
    const { state, reason } = this.computeState();
    return {
      ok: true,
      protocol: PROTOCOL_VERSION,
      bridgeVersion: BRIDGE_VERSION,
      state,
      reason,
      platform: process.platform,
      mcp: {
        state: this.mcp.state,
        command: this.mcp.commandLine,
        serverName: this.mcp.serverInfo.name,
        serverVersion: this.mcp.serverInfo.version,
        toolCount: this.mcp.tools.length,
        lastError: this.mcp.lastError,
      },
      studio: { processRunning: this.studioProcess, instances: this.studios, selected: this.selectedStudio(), placeOpen: this.placeOpen },
      session: this.sessions.current,
      settings: this.settings,
      pendingApprovals: this.approvals.list(),
    };
  }

  studioReady(): boolean {
    const s = this.computeState().state;
    return s === "MCP_READY" || s === "SESSION_ACTIVE";
  }

  // ------------------------------------------------------------------ sessions
  projectFor(sessionId?: string): ProjectMemory | undefined {
    const s = this.sessions.get(sessionId) ?? this.sessions.current ?? undefined;
    return s ? this.memory.get(s.projectKey) : undefined;
  }

  async startSession(provider: string, task?: string | null, opts: Pick<SessionPatch, "mode" | "category"> = {}): Promise<SessionStartResponse> {
    if (!this.studioReady()) {
      const { reason } = this.computeState();
      throw Object.assign(new Error(reason), { status: 409 });
    }
    const studio = this.selectedStudio();
    let name = studio?.name ?? "Untitled place";
    let placeId: string | number | null = studio?.placeId ?? null;
    let scan: ProjectMemory["scan"] = null;
    let place: Record<string, unknown> = {};
    const info = this.tools.get("get_project_info");
    if (this.config.composites && info?.available && info.composite) {
      try {
        const r = (await info.composite.run({}, this.compositeContext(undefined, undefined, "get_project_info"))) as Record<string, unknown>;
        place = { placeName: r.placeName, placeId: r.placeId, gameId: r.gameId, creatorId: r.creatorId, services: r.services, remotes: r.remotes };
        name = String(r.placeName ?? name);
        placeId = (r.placeId as number) || placeId;
        scan = {
          at: new Date().toISOString(),
          scripts: (r.scripts as Array<{ path: string; class: string }>) ?? [],
          guis: (r.guis as Array<{ path: string; class: string }>) ?? [],
          scriptCount: r.scriptCount as number,
          remotes: r.remotes as number,
        };
      } catch (e) {
        this.logger.warn("session.scan_failed", (e as Error).message);
      }
    }
    const key = projectKeyFor(placeId, name);
    const mem = this.memory.ensure(key, name, placeId);
    mem.name = name;
    mem.placeId = placeId;
    if (scan) mem.scan = scan;
    if (Object.keys(place).length) mem.place = place;
    const session = this.sessions.start(provider, key, name, task);
    if (opts.mode !== undefined || opts.category !== undefined) this.sessions.update(session.id, { mode: opts.mode ?? null, category: opts.category ?? null });
    mem.lastSession = { id: session.id, provider, startedAt: session.startedAt, task: task ?? null };
    this.memory.save(mem);
    this.logger.info("session.start", `${session.id} provider=${provider} project=${name}`, { sessionId: session.id, provider });
    this.emit("changed");
    return { session, tools: this.listTools(), memorySummary: this.memory.summary(mem) };
  }

  endSession(id: string) {
    const s = this.sessions.stop(id);
    if (s) {
      const m = this.memory.get(s.projectKey);
      if (m?.lastSession?.id === id) {
        m.lastSession.endedAt = s.endedAt;
        this.memory.save(m);
      }
      this.logger.info("session.stop", id, { sessionId: id, provider: s.provider });
      this.emit("changed");
    }
    return s;
  }

  updateSession(id: string, patch: SessionPatch) {
    const s = this.sessions.update(id, patch);
    this.emit("changed");
    return s;
  }

  // ------------------------------------------------------------------ calls
  /** Start a call; resolves when done or after waitMs (then poll getCall). */
  async submitCall(call: ToolCall, ctx: { sessionId?: string; provider?: string }, waitMs = 20000): Promise<CallEnvelope> {
    const callId = "c_" + crypto.randomBytes(6).toString("hex");
    const env: CallEnvelope & { waiters: Array<() => void>; createdAt: number } = {
      callId,
      state: "running",
      tool: String(call?.tool ?? ""),
      args: (call?.args as Record<string, unknown>) ?? {},
      waiters: [],
      createdAt: Date.now(),
    };
    this.calls.set(callId, env);
    this.gcCalls();
    void this.execute(call, ctx, (approval) => {
      env.state = "pending_approval";
      env.approvalId = approval.id;
      env.approvalReason = approval.reason;
      this.wake(env);
    }).then((result) => {
      env.state = "done";
      env.result = result;
      env.approvalId = undefined;
      this.wake(env);
    });
    return this.getCall(callId, waitMs, "running") as Promise<CallEnvelope>;
  }

  /** Long-poll: waits up to waitMs while the state still equals `since` (default: current state). */
  async getCall(callId: string, waitMs = 0, since?: string): Promise<CallEnvelope | undefined> {
    const env = this.calls.get(callId);
    if (!env) return undefined;
    const initial = since ?? env.state;
    if (env.state !== "done" && env.state === initial && waitMs > 0) {
      await new Promise<void>((resolve) => {
        const t = setTimeout(resolve, waitMs);
        env.waiters.push(() => {
          if ((env.state as string) !== initial) {
            clearTimeout(t);
            resolve();
          }
        });
      });
    }
    const { waiters: _w, createdAt: _c, ...pub } = env;
    return pub;
  }

  private wake(env: { waiters: Array<() => void> }) {
    const ws = env.waiters.splice(0);
    ws.forEach((w) => w());
    this.emit("changed");
  }

  private gcCalls() {
    const cutoff = Date.now() - 30 * 60000;
    for (const [id, c] of this.calls) if (c.createdAt < cutoff && c.state === "done") this.calls.delete(id);
  }

  /** The tool executor: validate → safety → approval → snapshot → run (timeout/retry) → record. */
  async execute(
    call: ToolCall,
    ctx: { sessionId?: string; provider?: string },
    onApproval: (a: { id: string; reason: string }) => void = () => undefined,
  ): Promise<ToolResult> {
    const t0 = Date.now();
    const id = String(call?.id ?? "?");
    const fin = (status: ToolResult["status"], result: unknown, error: string | null, meta: ToolResult["meta"] = {}): ToolResult => {
      const durationMs = Date.now() - t0;
      const r: ToolResult = { id, status, result, error, meta: { ...meta, durationMs, tool: call?.tool } };
      this.logger.log({
        level: status === "success" ? "info" : "warn",
        event: "tool.call",
        tool: call?.tool,
        args: clip(call?.args, 1500),
        result: clip(status === "success" ? result : error, 1500),
        status,
        durationMs,
        sessionId: ctx.sessionId,
        provider: ctx.provider,
      });
      this.sessions.countCall(ctx.sessionId, status !== "success");
      return r;
    };
    const shapeProblem = call && typeof call === "object" ? validateCallShape(call as unknown as Record<string, unknown>) : "call must be an object";
    if (shapeProblem) return fin("error", null, `invalid tool call: ${shapeProblem}`);
    const args = { ...(call.args ?? {}) };
    let tool = this.tools.get(call.tool);
    if (!tool || !tool.available) {
      // forgiving names: "run_code" / "functions.execute_luau" / "Execute-Luau" → the real tool
      const avail = [...this.tools.values()].filter((t) => t.available).map((t) => t.name);
      const real = resolveToolName(call.tool, avail);
      if (real && real !== call.tool) {
        this.logger.info("tool.alias", `${call.tool} → ${real}`, { sessionId: ctx.sessionId });
        tool = this.tools.get(real);
      }
    }
    if (tool && !tool.mcpName) {
      // the AI called the raw runner (run_code) — route through the alias so BW helpers + arg mapping apply
      const alias = this.tools.get("execute_luau");
      if (alias?.mcpName === tool.name) tool = alias;
    }
    if (!tool) {
      const names = [...this.tools.values()].filter((t) => t.available).map((t) => t.name);
      return fin("error", null, `unknown tool "${call.tool}". Available tools: ${names.slice(0, 30).join(", ")}. Did you mean: ${closestNames(call.tool, names).join(", ")}?`);
    }
    if (!tool.available) return fin("error", null, `tool "${tool.name}" unavailable: ${tool.unavailableReason}`);
    if (tool.source !== "bridge" && !this.studioReady()) return fin("error", null, this.computeState().reason);

    const coerced = coerceArgs(tool.inputSchema, args);
    if (coerced.length) this.logger.info("tool.args_coerced", `${tool.name}: ${coerced.join(", ")}`, { sessionId: ctx.sessionId });
    // fill studio_id / datamodel_type for MCP tools
    if (tool.source === "mcp") {
      const fill = this.autofill(tool, args);
      if (fill) return fin("error", null, fill);
    }
    const errors = validateArgs(tool.inputSchema, args);
    if (errors.length) return fin("error", null, `invalid arguments: ${errors.slice(0, 6).join("; ")}`);

    // safety
    const mem = this.projectFor(ctx.sessionId);
    const { risk, reasons } = assessCall(tool, args, this.memory.importantPaths(mem));
    const sess = this.sessions.get(ctx.sessionId);
    let decision = decide(sess?.mode ?? this.settings.mode, risk, reasons);
    if (sess?.trustAll && decision.action === "confirm") decision = { action: "allow" };
    if (decision.action === "deny") return fin("denied", null, decision.reason);
    if (decision.action === "confirm") {
      const { approval, decision: wait } = this.approvals.request(
        { callId: id, tool: tool.name, args: clip(args, 3000) as Record<string, unknown>, reason: decision.reason, sessionId: ctx.sessionId },
        this.settings.approvalTimeoutMs,
      );
      this.logger.info("approval.requested", `${tool.name}: ${decision.reason}`, { tool: tool.name, sessionId: ctx.sessionId });
      onApproval({ id: approval.id, reason: decision.reason });
      const ok = await wait;
      if (ok !== true) {
        this.logger.info("approval.denied", `${tool.name}: ${ok === "timeout" ? "timed out" : "rejected by user"}`);
        return fin("rejected", null, ok === "timeout" ? "approval timed out — action not executed" : "user rejected this action — not executed. Ask the user or choose a safer approach.");
      }
      this.logger.info("approval.granted", tool.name);
    }

    // auto snapshot
    let snapshotId: string | undefined;
    if (this.settings.autoSnapshot && risk !== "read" && tool.name !== "take_snapshot" && tool.name !== "restore_snapshot") {
      const targets = tool.composite?.snapshotTargets?.(args) ?? this.mcpSnapshotTargets(tool, args);
      if (targets.length && this.tools.get("take_snapshot")?.available) {
        try {
          const snap = (await this.tools.get("take_snapshot")!.composite!.run({ paths: targets, label: `auto before ${tool.name}` }, this.compositeContext(ctx.sessionId, undefined, "take_snapshot"))) as { snapshot: SnapshotRecord };
          snapshotId = snap.snapshot.id;
          this.storeSnapshot(snap.snapshot, ctx.sessionId);
        } catch (e) {
          this.logger.warn("snapshot.auto_failed", (e as Error).message);
        }
      }
    }

    // run with timeout + retry (reads only)
    const timeout = LONG_TOOLS.test(tool.name) ? Math.max(this.settings.toolTimeoutMs, 180000) : this.settings.toolTimeoutMs;
    let retries = 0;
    for (;;) {
      try {
        let result = await this.runTool(tool, args, timeout, ctx.sessionId);
        if (tool.name === "take_snapshot") {
          const rec = (result as { snapshot: SnapshotRecord }).snapshot;
          this.storeSnapshot(rec, ctx.sessionId);
          result = { snapshotId: rec.id, entries: rec.entries.map((e) => ({ path: e.path, saved: e.saved, absent: e.absent })) };
        }
        if (tool.name === "restore_snapshot") {
          const rec = mem?.snapshots.find((s) => s.id === args.snapshotId);
          if (rec && mem) {
            rec.restoredAt = new Date().toISOString();
            this.memory.save(mem);
          }
        }
        if (risk !== "read" && mem && tool.source !== "bridge") this.memory.addChange(mem, tool.name, summarize(tool.name, args), ctx.sessionId);
        return fin("success", result, null, { retries, snapshotId });
      } catch (e) {
        const err = e as Error & { code?: string };
        const transient = err instanceof McpError && (err.code === "timeout" || err.code === "disconnected" || err.code === "not_ready");
        if (transient && risk === "read" && retries < 1) {
          retries++;
          this.logger.warn("tool.retry", `${tool.name}: ${err.message}`);
          await this.waitForMcp(10000);
          continue;
        }
        if (mem) this.memory.addError(mem, tool.name, err.message, ctx.sessionId);
        const status = err instanceof McpError && err.code === "timeout" ? "timeout" : "error";
        return fin(status, null, `${err.message}${retries ? ` (after ${retries} retry)` : ""}`, { retries, snapshotId });
      }
    }
  }

  private storeSnapshot(rec: SnapshotRecord, sessionId?: string) {
    const mem = this.projectFor(sessionId);
    if (!mem) return;
    rec.sessionId = sessionId;
    mem.snapshots.push(rec);
    if (mem.snapshots.length > 60) mem.snapshots.splice(0, mem.snapshots.length - 60);
    this.memory.save(mem);
  }

  private mcpSnapshotTargets(tool: BridgeTool, args: Record<string, unknown>): string[] {
    if (tool.source !== "mcp" || tool.name === "execute_luau") return [];
    for (const k of ["path", "script_path", "target", "file_path", "instance_path"]) {
      const v = args[k];
      if (typeof v === "string" && /^game[.:[]/.test(v)) return [v];
    }
    return [];
  }

  private autofill(tool: BridgeTool, args: Record<string, unknown>): string | null {
    const props = tool.inputSchema.properties ?? {};
    const req = tool.inputSchema.required ?? [];
    if ("studio_id" in props && args.studio_id === undefined) {
      const s = this.selectedStudio();
      if (s) args.studio_id = s.id;
      else if (req.includes("studio_id")) return "Studio unavailable: no Studio instance connected (open a place with 'Studio as MCP server' enabled).";
    }
    if ("datamodel_type" in props && args.datamodel_type === undefined) {
      const en = props.datamodel_type.enum as string[] | undefined;
      args.datamodel_type = en?.includes("Edit") ? "Edit" : en?.[0] ?? "Edit";
    }
    return null;
  }

  private async waitForMcp(ms: number) {
    const end = Date.now() + ms;
    while (Date.now() < end && this.mcp.state !== "ready") await new Promise((r) => setTimeout(r, 250));
  }

  private async runTool(tool: BridgeTool, args: Record<string, unknown>, timeout: number, sessionId?: string): Promise<unknown> {
    if (tool.bridgeRun) return tool.bridgeRun(args, sessionId);
    if (tool.composite) return tool.composite.run(args, this.compositeContext(sessionId, timeout, tool.name));
    // BW helper library: prepended only to Luau that uses it; error line numbers mapped back to the AI's code.
    if (tool.name === "execute_luau" && this.config.luauHelpers && typeof args.code === "string" && usesHelpers(args.code)) {
      const inj = this.assets.injectionFor(args.code);
      if (inj?.ids.length) this.logger.info("assets.inject", `${inj.ids.length} asset(s), ${Math.round(inj.bytes / 1024)} KB${inj.missing.length ? `; unknown: ${inj.missing.join(", ")}` : ""}`, { sessionId });
      const prep = prepareLuau(args.code, inj?.luau);
      try {
        return await this.runMcp(tool, { ...args, code: prep.code }, timeout, prep.preludeLines);
      } catch (e) {
        throw new Error(remapLuauLines((e as Error).message, prep.preludeLines));
      }
    }
    return this.runMcp(tool, args, timeout, 0);
  }

  /** Real MCP name + argument mapping for alias tools (execute_luau → run_code {command}). */
  private mcpCall(tool: BridgeTool, args: Record<string, unknown>): [string, Record<string, unknown>] {
    if (!tool.mcpName) return [tool.name, args];
    const a = { ...args };
    if (tool.codeKey && tool.codeKey !== "code" && a.code !== undefined) {
      a[tool.codeKey] = a.code;
      delete a.code;
    }
    return [tool.mcpName, a];
  }

  private async runMcp(tool: BridgeTool, args0: Record<string, unknown>, timeout: number, helpers: number): Promise<unknown> {
    const [name, args] = this.mcpCall(tool, args0);
    let r = normalizeMcpResult(await this.mcp.callTool(name, args, timeout));
    if (looksLikeStudioDrop(r.text)) {
      // Studio blinked (place switch / restart): retry once after a short wait, then report honestly.
      this.logger.warn("tool.studio_drop", `${tool.name}: ${r.text.slice(0, 200)}`);
      await new Promise((res) => setTimeout(res, 1500));
      void this.pollStudios();
      r = normalizeMcpResult(await this.mcp.callTool(name, args, timeout));
      if (looksLikeStudioDrop(r.text)) throw new Error(`Studio unavailable: ${r.text.slice(0, 300)}`);
    }
    if (r.isError) throw new Error(r.text || `${tool.name} failed`);
    if (helpers && typeof (r.json ?? r.text) === "string") return remapLuauLines(r.text, helpers);
    return r.json ?? r.text;
  }

  compositeContext(sessionId?: string, timeout = this.settings.toolTimeoutMs, op = "composite"): CompositeContext {
    return {
      newId: (p) => `${p}_${Date.now().toString(36)}${crypto.randomBytes(2).toString("hex")}`,
      getSnapshot: (id) => this.projectFor(sessionId)?.snapshots.find((s) => s.id === id),
      listSnapshots: () => this.projectFor(sessionId)?.snapshots ?? [],
      callMcp: async (name, a) => {
        const t = this.tools.get(name);
        const args = { ...a };
        if (t) this.autofill(t, args);
        const r = normalizeMcpResult(await this.mcp.callTool(name, args, timeout));
        if (r.isError) throw new Error(r.text || `${name} failed`);
        return r;
      },
      runLuau: async (code) => {
        const t = this.tools.get("execute_luau");
        if (!t || t.source !== "mcp") throw new Error("execute_luau not provided by Studio MCP");
        const props = t.inputSchema.properties ?? {};
        const codeKey =
          ["code", "source", "luau", "script", "command"].find((k) => k in props) ??
          Object.keys(props).find((k) => props[k].type === "string" && !/studio_id|datamodel/i.test(k)) ??
          "code";
        let body = `--@bw-op ${op}\n` + code;
        if (this.luauPrint || t.mcpName) body = body.replace(/\nreturn __s\n$/, "\nprint(__s)\nreturn __s\n");
        const args0: Record<string, unknown> = { [codeKey]: body };
        const fill = this.autofill(t, args0);
        if (fill) throw new Error(fill);
        const [name, args] = this.mcpCall(t, args0);
        const r = normalizeMcpResult(await this.mcp.callTool(name, args, timeout));
        let p = extractLuauPayload(r.text);
        if (!p.found && this.tools.get("get_console_output")?.available) {
          // Some Studio builds only surface printed output — look there.
          try {
            const out = await this.compositeContext(sessionId, 15000, op).callMcp("get_console_output", {});
            const idx = out.text.lastIndexOf("BWJSON<<");
            if (idx >= 0) p = extractLuauPayload(out.text.slice(idx));
          } catch {
            /* ignore */
          }
          if (!p.found && !this.luauPrint) {
            this.luauPrint = true;
            this.logger.warn("luau.print_mode", "execute_luau did not return values; switching to print mode for following calls");
          }
        }
        if (!p.found) {
          if (r.isError) throw new Error(r.text.slice(0, 1500));
          throw new Error(`execute_luau returned no Brickwire payload (raw: ${r.text.slice(0, 400)})`);
        }
        if (!p.ok) throw new Error(p.error ?? "Luau error");
        return p.result;
      },
    };
  }

  /** Expose for tests/tools: raw Luau code a composite would run is opaque; but execute_luau risk needs code. */
  static luauOf(args: Record<string, unknown>) {
    return findLuauCode(args);
  }
}

function summarize(tool: string, a: Record<string, unknown>): string {
  const target = a.path ?? (a.parent && (a.name || (a.tree as { name?: string })?.name) ? `${a.parent}.${a.name ?? (a.tree as { name?: string }).name}` : a.parent) ?? a.snapshotId ?? "";
  return `${tool} ${String(target)}`.trim();
}
