import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { PROVIDERS } from "../../shared/src/providers.js";
import type { Bridge } from "./bridge.js";
import { MEMORY_CATEGORIES, type MemoryCategory } from "./memory.js";
import type { LogEntry, ToolCall } from "../../shared/src/protocol.js";

/**
 * Local HTTP API (127.0.0.1 only).
 * Security: rejects foreign web origins (only chrome-extension:// / the dashboard itself / no-origin local tools),
 * validates Host header against DNS rebinding, and caps body size.
 */

const MAX_BODY = 2 * 1024 * 1024;

function findDashboard(): string | null {
  const here = path.dirname(fileURLToPath(import.meta.url));
  for (const p of [path.join(here, "dashboard.html"), path.join(here, "..", "src", "dashboard.html"), path.join(here, "..", "dist", "dashboard.html")]) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

export function originAllowed(origin: string | undefined, port: number): boolean {
  if (!origin) return true; // local CLI tools (curl, scripts) — they already have local access
  if (/^(chrome|moz)-extension:\/\/[a-z0-9-]+$/i.test(origin)) return true;
  if (origin === `http://127.0.0.1:${port}` || origin === `http://localhost:${port}`) return true;
  return false;
}

export function hostAllowed(host: string | undefined, port: number): boolean {
  if (!host) return false;
  return host === `127.0.0.1:${port}` || host === `localhost:${port}` || host === `[::1]:${port}`;
}

export function createServer(bridge: Bridge, opts: { onShutdown?: () => void } = {}) {
  const port = bridge.config.port;
  const dashFile = findDashboard();
  const sseClients = new Set<http.ServerResponse>();

  const broadcast = (event: string, data: unknown) => {
    const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
    for (const c of sseClients) c.write(payload);
  };
  let pendingHealth: NodeJS.Timeout | null = null;
  bridge.on("changed", () => {
    if (pendingHealth) return;
    pendingHealth = setTimeout(() => {
      pendingHealth = null;
      broadcast("health", bridge.health());
    }, 150);
  });
  bridge.logger.on("log", (e: LogEntry) => {
    if (e.level !== "debug") broadcast("log", e);
  });

  const server = http.createServer(async (req, res) => {
    const origin = req.headers.origin;
    const send = (status: number, body: unknown, headers: Record<string, string> = {}) => {
      const h: Record<string, string> = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...headers };
      if (origin && originAllowed(origin, port)) {
        h["Access-Control-Allow-Origin"] = origin;
        h["Vary"] = "Origin";
      }
      res.writeHead(status, h);
      res.end(typeof body === "string" && h["Content-Type"].startsWith("text/") ? body : JSON.stringify(body));
    };
    try {
      if (!hostAllowed(req.headers.host, port)) return send(403, { ok: false, error: "forbidden host" });
      if (!originAllowed(origin, port)) {
        bridge.logger.warn("http.forbidden_origin", String(origin));
        return send(403, { ok: false, error: "forbidden origin" });
      }
      if (req.method === "OPTIONS") {
        res.writeHead(204, {
          "Access-Control-Allow-Origin": origin ?? "*",
          "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Private-Network": "true",
          "Access-Control-Max-Age": "600",
        });
        return res.end();
      }
      const url = new URL(req.url ?? "/", `http://127.0.0.1:${port}`);
      const p = url.pathname;
      const body = req.method === "POST" || req.method === "PUT" ? await readJson(req) : {};

      if (req.method === "GET" && (p === "/" || p === "/dashboard" || p.startsWith("/dashboard/"))) {
        if (!dashFile) return send(500, "dashboard.html missing", { "Content-Type": "text/plain" });
        return send(200, fs.readFileSync(dashFile, "utf8"), { "Content-Type": "text/html; charset=utf-8" });
      }
      if (req.method === "GET" && p === "/api/health") return send(200, bridge.health());
      if (req.method === "GET" && p === "/api/events") {
        res.writeHead(200, {
          "Content-Type": "text/event-stream",
          "Cache-Control": "no-store",
          Connection: "keep-alive",
          ...(origin ? { "Access-Control-Allow-Origin": origin } : {}),
        });
        res.write(`event: health\ndata: ${JSON.stringify(bridge.health())}\n\n`);
        sseClients.add(res);
        const ka = setInterval(() => res.write(": ka\n\n"), 15000);
        req.on("close", () => {
          clearInterval(ka);
          sseClients.delete(res);
        });
        return;
      }
      if (req.method === "GET" && p === "/api/tools") return send(200, { tools: bridge.listTools() });
      if (req.method === "POST" && p === "/api/tools/refresh") {
        if (bridge.mcp.state === "ready") await bridge.mcp.refreshTools();
        return send(200, { tools: bridge.listTools() });
      }
      if (req.method === "POST" && p === "/api/mcp/restart") {
        void bridge.mcp.restart();
        return send(200, { ok: true });
      }
      if (req.method === "GET" && p === "/api/providers") return send(200, { providers: PROVIDERS });

      if (req.method === "POST" && p === "/api/sessions/start") {
        try {
          return send(200, await bridge.startSession(String(body.provider ?? "unknown"), body.task ? String(body.task) : null, { mode: body.mode, category: body.category }));
        } catch (e) {
          const err = e as Error & { status?: number };
          return send(err.status ?? 500, { ok: false, error: err.message });
        }
      }
      if (req.method === "POST" && p === "/api/sessions/stop") {
        const s = bridge.endSession(String(body.sessionId ?? bridge.sessions.current?.id ?? ""));
        bridge.approvals.rejectAll();
        return send(s ? 200 : 404, s ? { session: s } : { ok: false, error: "no such session" });
      }
      if (req.method === "POST" && p === "/api/sessions/update") {
        const s = bridge.updateSession(String(body.sessionId), { stage: body.stage, task: body.task, mode: body.mode, category: body.category, trustAll: body.trustAll });
        return send(s ? 200 : 404, s ? { session: s } : { ok: false, error: "no such session" });
      }
      if (req.method === "GET" && p === "/api/sessions") return send(200, { sessions: bridge.sessions.list() });

      if (req.method === "POST" && p === "/api/calls") {
        const sessionId = body.sessionId ? String(body.sessionId) : undefined;
        if (sessionId && !bridge.sessions.get(sessionId)?.active) return send(409, { ok: false, error: "session is not active" });
        const env = await bridge.submitCall(body.call as ToolCall, { sessionId, provider: body.provider ? String(body.provider) : undefined }, clampWait(body.waitMs));
        return send(200, env);
      }
      const callMatch = p.match(/^\/api\/calls\/([A-Za-z0-9_]+)$/);
      if (req.method === "GET" && callMatch) {
        const env = await bridge.getCall(callMatch[1], clampWait(url.searchParams.get("wait")), url.searchParams.get("since") ?? undefined);
        return send(env ? 200 : 404, env ?? { ok: false, error: "unknown call" });
      }

      if (req.method === "GET" && p === "/api/approvals") return send(200, { approvals: bridge.approvals.list() });
      const apMatch = p.match(/^\/api\/approvals\/([A-Za-z0-9_]+)$/);
      if (req.method === "POST" && apMatch) {
        const ok = bridge.approvals.decide(apMatch[1], body.approve === true);
        return send(ok ? 200 : 404, { ok });
      }

      if (req.method === "GET" && p === "/api/projects") return send(200, { projects: bridge.memory.list() });
      const prMatch = p.match(/^\/api\/projects\/([A-Za-z0-9_-]+)(\/notes)?$/);
      if (prMatch && req.method === "GET" && !prMatch[2]) {
        const m = bridge.memory.get(prMatch[1]);
        return send(m ? 200 : 404, m ? { project: m, summary: bridge.memory.summary(m) } : { ok: false });
      }
      if (prMatch && prMatch[2] && req.method === "POST") {
        const m = bridge.memory.get(prMatch[1]);
        if (!m) return send(404, { ok: false });
        const cat = String(body.category) as MemoryCategory;
        if (!MEMORY_CATEGORIES.includes(cat)) return send(400, { ok: false, error: "bad category" });
        if (typeof body.remove === "number") bridge.memory.removeItem(m, cat, body.remove);
        else bridge.memory.addItem(m, cat, String(body.text ?? ""), body.path ? String(body.path) : undefined);
        return send(200, { project: m });
      }

      if (req.method === "GET" && p === "/api/logs") {
        const limit = Math.min(2000, Number(url.searchParams.get("limit") ?? 300));
        const tool = url.searchParams.get("tool");
        const level = url.searchParams.get("level");
        return send(200, {
          logs: bridge.logger.recent(limit, (e) => (!tool || e.tool === tool) && (!level || e.level === level) && (url.searchParams.get("calls") ? e.event === "tool.call" : true)),
        });
      }
      if (req.method === "GET" && p === "/api/settings") return send(200, { settings: bridge.settings });
      if ((req.method === "PUT" || req.method === "POST") && p === "/api/settings") return send(200, { settings: bridge.saveSettings(body) });
      const snapMatch = p.match(/^\/api\/snapshots\/([A-Za-z0-9_]+)\/restore$/);
      if (req.method === "POST" && snapMatch) {
        // Dashboard-initiated rollback. Goes through the normal executor (approval rules still apply).
        const env = await bridge.submitCall(
          { id: "dash_restore_" + Date.now().toString(36), tool: "restore_snapshot", args: { snapshotId: snapMatch[1] } },
          { provider: "dashboard" },
          clampWait(body.waitMs ?? 2000),
        );
        return send(200, env);
      }
      if (req.method === "POST" && p === "/api/studio/select") {
        return send(200, { settings: bridge.saveSettings({ selectedStudioId: body.studioId ? String(body.studioId) : null }) });
      }
      if (req.method === "POST" && p === "/api/shutdown") {
        send(200, { ok: true });
        setTimeout(() => opts.onShutdown?.(), 100);
        return;
      }
      return send(404, { ok: false, error: `no route ${req.method} ${p}` });
    } catch (e) {
      bridge.logger.error("http.error", (e as Error).message);
      return send((e as { status?: number }).status ?? 500, { ok: false, error: (e as Error).message });
    }
  });
  server.on("close", () => {
    for (const c of sseClients) c.end();
  });
  return server;
}

function clampWait(v: unknown): number {
  const n = Number(v ?? 20000);
  return Number.isFinite(n) ? Math.min(25000, Math.max(0, n)) : 20000;
}

function readJson(req: http.IncomingMessage): Promise<Record<string, any>> {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks: Buffer[] = [];
    req.on("data", (c: Buffer) => {
      size += c.length;
      if (size > MAX_BODY) {
        reject(Object.assign(new Error("body too large"), { status: 413 }));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => {
      if (!chunks.length) return resolve({});
      try {
        const v = JSON.parse(Buffer.concat(chunks).toString("utf8"));
        resolve(v && typeof v === "object" ? v : {});
      } catch {
        reject(Object.assign(new Error("invalid JSON body"), { status: 400 }));
      }
    });
    req.on("error", reject);
  });
}
