#!/bin/sh
set -eu
cd "$(dirname "$0")" || exit 1

./stop.command >/dev/null 2>&1 || true

if [ -d .git ]; then
  echo "[i] Updating from git..."
  git pull --ff-only
  npm install
  npm run build
else
  echo "[i] This is a release folder (no .git)."
  echo "    Download the new release and replace this folder; keep .env and data/."
  exit 0
fi

echo "[OK] Updated and rebuilt. Reload the extension and run ./start.command."
