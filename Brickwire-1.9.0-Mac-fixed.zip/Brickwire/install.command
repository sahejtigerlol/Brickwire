#!/bin/sh
set -eu
cd "$(dirname "$0")" || exit 1

command -v node >/dev/null 2>&1 || {
  echo "[X] Node.js 20+ is required. Install it from https://nodejs.org/ and run this again."
  exit 1
}

major="$(node -p 'process.versions.node.split(".")[0]')"
if [ "$major" -lt 20 ]; then
  echo "[X] Node.js 20+ is required (found $(node --version))."
  exit 1
fi

[ -f .env ] || { [ -f .env.example ] && cp .env.example .env; }

echo "[i] Installing dependencies..."
npm install

echo "[i] Building Brickwire..."
npm run build

chmod +x start.command stop.command update.command 2>/dev/null || true

echo "[OK] Brickwire is installed and built."
echo "    1. Load extension/dist as an unpacked extension in Chrome/Chromium."
echo "    2. Open Roblox Studio, enable its Studio MCP server, and open a place."
echo "    3. Run ./start.command"
